//
//  Person.swift
//  Mct
//
//  Created by maher deeb on 08/09/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import Foundation

class Person{
    
    var personFirstName  : String
    var personLastName  : String
    var personAge : Int
    var personPhoneNumber : String
    var personEmailAdress : String
    var personCountry : String
    var personCity : String
    var personZipCode : Double
    var personIdNumber : String
    var personCarLicense : String
    var userName : String
    var password : String
    var adress : String
    
    
    init(firstName:String,lastName:String,age:Int,phoneNumber:String,adress:String,email:String,personCountry:String,personCity:String,personZipCode:Double,idNumber:String,carLicense:String,userName:String,passWord:String) {
        
        self.personFirstName = firstName
        self.personLastName = lastName
        self.personAge = age
        self.personPhoneNumber = phoneNumber
        self.personEmailAdress = email
        self.personCountry = personCountry
        self.personCity = personCity
        self.personZipCode = personZipCode
        self.personIdNumber = idNumber
        self.personCarLicense = carLicense
        self.userName = userName
        self.password = passWord
        self.adress = adress
        
    }
    
}
