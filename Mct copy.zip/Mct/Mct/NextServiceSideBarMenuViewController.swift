//
//  NextServiceSideBarMenuViewController.swift
//  Mct
//
//  Created by maher deeb on 07/09/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class NextServiceSideBarMenuViewController: UIViewController {

    @IBOutlet weak var nextService: UILabel!
    @IBOutlet weak var parts: UILabel!
    
    @IBOutlet weak var btnMenuButton: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        btnMenuButton.target = revealViewController()
        btnMenuButton.action = #selector(SWRevealViewController.revealToggle(_:))

     
         nextService.text = User.shared.cars[CommonValues.count].serviceHistory.rawValue
        parts.text = User.shared.cars[CommonValues.count].serviceHistory.caseService()
    }

   
}
