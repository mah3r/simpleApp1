//
//  ServiceCentersSideBarMenuViewController.swift
//  Mct
//
//  Created by maher deeb on 07/09/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class ServiceCentersSideBarMenuViewController: UIViewController,UITableViewDataSource , UITableViewDelegate {

   
    
    @IBOutlet weak var serviceCenterTableView: UITableView!
    @IBOutlet weak var btnMenuButton: UIBarButtonItem!
   
    let mayerCenters : [String:String] = ["erez":"haifa\n041234566\nopen san to thu from 7:30 till 16:30\narrival discription",
                                            "maloat": "malot\n045456754\nopen san to thu from 7:30 till 16:30\narrival discription",
                                            "hedera":"hedera\n0456555496\nopen san to thu from 7:30 till 16:30\narrival discription",
                                            "reshon letzion": "reshon\n032123345\nopen san to thu from 7:30 till 16:30\narrival discription"]
    var index = 0
    var selctedCenter : String = ""
    var selctedCenterDetails : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        btnMenuButton.target = revealViewController()
        btnMenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
        // Do any additional setup after loading the view.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return mayerCenters.keys.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "centerCell") as! ServiceCentersTableViewCell
        
        cell.label.text = Array(mayerCenters.keys)[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        index = indexPath.row
        selctedCenter = Array(mayerCenters.keys)[index]
        selctedCenterDetails = Array(mayerCenters.values)[index]
        
        performSegue(withIdentifier: "segue3", sender: nil)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let centerDetailsViewController = segue.destination as? CenterDetailsViewController{
            
            centerDetailsViewController.name = selctedCenter
            centerDetailsViewController.details = selctedCenterDetails
            
            
        }
   
    }
        
    
    
    
}
