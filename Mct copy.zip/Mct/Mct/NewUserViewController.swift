//
//  NewUserViewController.swift
//  Mct
//
//  Created by maher deeb on 28/09/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class NewUserViewController: UIViewController {
  
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var userId: UITextField!
    @IBOutlet weak var userCarLicense: UITextField!
    @IBOutlet weak var userPassword: UITextField!
    @IBOutlet weak var userPasswordValidation: UITextField!
    @IBOutlet weak var userEmail: UITextField!
    @IBOutlet weak var userEmailValidation: UITextField!
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func saveBtn(_ sender: UIBarButtonItem) {
        
        let newUser = Person(firstName: "", lastName: "", age: 0, phoneNumber: "", adress: "", email: userEmail.text!, personCountry: "", personCity: "", personZipCode: 0, idNumber: userId.text!, carLicense: userCarLicense.text!, userName: userName.text!, passWord: userPassword.text!)
        if userPasswordValidation.text == userPassword.text{
            if userEmailValidation.text == userEmail.text{
                User.shared.persons.append(newUser)
                dismiss(animated: true, completion: nil)
            }else{
                userEmailValidation.text = "Wrong email"
            }
            }else{
                userPasswordValidation.text = "wrong password"
            }
        }
    
    @IBAction func cancelBtn(_ sender: UIBarButtonItem) {
         dismiss(animated: true, completion: nil)
    }
    
    
    
    
}
