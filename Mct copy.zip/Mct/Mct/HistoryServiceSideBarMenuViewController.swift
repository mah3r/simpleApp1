//
//  HistoryServiceSideBarMenuViewController.swift
//  Mct
//
//  Created by maher deeb on 07/09/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class HistoryServiceSideBarMenuViewController: UIViewController, UITableViewDataSource , UITableViewDelegate {

   @IBOutlet weak var btnMenuButton: UIBarButtonItem!
    
    
    var count = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        btnMenuButton.target = revealViewController()
        btnMenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
        // Do any additional setup after loading the view.
        
        
    }
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        count = 0
       
        for x in 0..<User.shared.cars.count{
            if User.shared.persons[CommonValues.count].personCarLicense == User.shared.cars[x].carLicenseNumber{
                count += 1
            }
        }
        return count
        }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "historyService") as! HistoryTableViewCell
        
        cell.label.text = User.shared.cars[indexPath.row].serviceHistory.rawValue
        
        return cell
    }

}
