//
//  User.swift
//  Mct
//
//  Created by maher deeb on 12/10/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import Foundation

class User {
    
    static var shared = User()
    private init (){}
    
    var persons : [Person] = []
    var cars : [Car] = []
    
    
}
