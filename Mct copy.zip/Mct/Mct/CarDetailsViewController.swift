//
//  CarDetailsViewController.swift
//  Mct
//
//  Created by maher deeb on 26/10/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class CarDetailsViewController: UIViewController {

    @IBOutlet weak var btnMenuButton: UIBarButtonItem!
    @IBOutlet weak var carManufacturer: UILabel!
    @IBOutlet weak var carVinNumber: UILabel!
    @IBOutlet weak var carManufacturingdate: UILabel!
    @IBOutlet weak var carEngineCapacity: UILabel!
    @IBOutlet weak var carHorsePower: UILabel!
    @IBOutlet weak var carKiloMeters: UILabel!
    @IBOutlet weak var carLicenseNumber: UILabel!
    @IBOutlet weak var carRoadImmegrationDate: UILabel!
    @IBOutlet weak var carModel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        btnMenuButton.target = revealViewController()
        btnMenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
        
        for (index , x)in User.shared.cars.enumerated(){
            if x.carLicenseNumber == User.shared.persons[CommonValues.count].personCarLicense{
                
                carModel.text = User.shared.cars[index].carModel
                carManufacturer.text = User.shared.cars[index].carManufacturer
                carVinNumber.text = User.shared.cars[index].carVinNumber
                carManufacturingdate.text = User.shared.cars[index].carManufacturingdate
                carRoadImmegrationDate.text = User.shared.cars[index].carRoadImmegrationDate
                carEngineCapacity.text = String(User.shared.cars[index].carEngineCapacity)
                carHorsePower.text = String(User.shared.cars[index].carHorsePower)
                carLicenseNumber.text = User.shared.cars[index].carLicenseNumber
                carKiloMeters.text = String(User.shared.cars[index].carKiloMeters)
                
            }
            
        }
        
       
        
    }

   
}
