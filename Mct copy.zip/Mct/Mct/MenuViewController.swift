//
//  MenuViewController.swift
//  Mct
//
//  Created by maher deeb on 07/09/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController , UITableViewDataSource , UITableViewDelegate {

    var menuNameArray : [String] = []
        
        
    override func viewDidLoad() {
        super.viewDidLoad()


        // Do any additional setup after loading the view.
        menuNameArray = ["Profile","Car Details","Next Service","Service Centers","History Services","Order Service","Edit Profile","Log Out"]
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuNameArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuTableViewCell") as! MenuTableViewCell
        
        cell.lbMenuName.text = menuNameArray[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let revealViewController:SWRevealViewController = self.revealViewController()
        
        let cell: MenuTableViewCell = tableView.cellForRow(at: indexPath) as! MenuTableViewCell
        
        if cell.lbMenuName.text == "Profile"{
            let mainStoryBoard : UIStoryboard = UIStoryboard(name:"Main", bundle: nil)
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "ProfileSideBarMenuViewController") as! ProfileSideBarMenuViewController
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
        }
        if cell.lbMenuName.text == "Car Details"{
            let mainStoryBoard : UIStoryboard = UIStoryboard(name:"Main", bundle: nil)
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "CarDetailsViewController") as! CarDetailsViewController
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
        }
        if cell.lbMenuName.text == "Next Service"{
            let mainStoryBoard : UIStoryboard = UIStoryboard(name:"Main", bundle: nil)
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "NextServiceSideBarMenuViewController") as! NextServiceSideBarMenuViewController
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
        }
        if cell.lbMenuName.text == "Service Centers"{
            let mainStoryBoard : UIStoryboard = UIStoryboard(name:"Main", bundle: nil)
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "ServiceCentersSideBarMenuViewController") as! ServiceCentersSideBarMenuViewController
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
        }
        if cell.lbMenuName.text == "History Services"{
            let mainStoryBoard : UIStoryboard = UIStoryboard(name:"Main", bundle: nil)
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "HistoryServiceSideBarMenuViewController") as! HistoryServiceSideBarMenuViewController
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
        }
        if cell.lbMenuName.text == "Order Service"{
            let mainStoryBoard : UIStoryboard = UIStoryboard(name:"Main", bundle: nil)
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "OrderServiceSideBarMenuViewController") as! OrderServiceSideBarMenuViewController
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
        }
        if cell.lbMenuName.text == "Edit Profile"{
            let mainStoryBoard : UIStoryboard = UIStoryboard(name:"Main", bundle: nil)
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "EditProfileViewController") as! EditProfileViewController
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
        }
        if cell.lbMenuName.text == "Log Out"{
            User.shared.cars.removeAll()
            User.shared.persons.removeAll()
            let mainStoryBoard : UIStoryboard = UIStoryboard(name:"Main", bundle: nil)
            let desController = mainStoryBoard.instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
            let newFrontViewController = UINavigationController.init(rootViewController:desController)
            revealViewController.pushFrontViewController(newFrontViewController, animated: true)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
