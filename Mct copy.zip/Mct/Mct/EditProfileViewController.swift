//
//  EditProfileViewController.swift
//  Mct
//
//  Created by maher deeb on 16/10/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class EditProfileViewController: UIViewController {

    @IBOutlet weak var btnMenuButton: UIBarButtonItem!
    @IBOutlet weak var firstNameLabel: UITextField!
    @IBOutlet weak var lastNameLabel: UITextField!
    @IBOutlet weak var ageLabel: UITextField!
    @IBOutlet weak var phoneNumberLabel: UITextField!
    @IBOutlet weak var emailAdressLabel: UITextField!
    @IBOutlet weak var countryLabel: UITextField!
    @IBOutlet weak var cityLabel: UITextField!
    @IBOutlet weak var zipCodeLabel: UITextField!
    @IBOutlet weak var idNumberLabel: UITextField!
    @IBOutlet weak var carLicenseTLabel: UITextField!
    @IBOutlet weak var adressLabel: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        btnMenuButton.target = revealViewController()
        btnMenuButton.action = #selector(SWRevealViewController.revealToggle(_:))
        loadProfileDetailes()
    }
    
    
    @IBAction func saveProfile(_ sender: UIButton) {
        saveProfileDetailes()
        performSegue(withIdentifier: "segue", sender: nil)
    }
    
    @IBAction func cancelBtn(_ sender: UIButton) {
        performSegue(withIdentifier: "segue", sender: nil)
    }
    

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let viewProfileSideBarMenuViewController = segue.destination as? ProfileSideBarMenuViewController{
            let profileView = User.shared.persons[CommonValues.count]
            viewProfileSideBarMenuViewController.person = profileView
        }
    }
    
    func loadProfileDetailes(){
        firstNameLabel.text = User.shared.persons[CommonValues.count].personFirstName
        lastNameLabel.text = User.shared.persons[CommonValues.count].personLastName
        ageLabel.text = String(describing: User.shared.persons[CommonValues.count].personAge)
        phoneNumberLabel.text = User.shared.persons[CommonValues.count].personPhoneNumber
        emailAdressLabel.text = User.shared.persons[CommonValues.count].personEmailAdress
        countryLabel.text = User.shared.persons[CommonValues.count].personCountry
        cityLabel.text = User.shared.persons[CommonValues.count].personCity
        zipCodeLabel.text = String(describing: User.shared.persons[CommonValues.count].personZipCode)
        idNumberLabel.text = User.shared.persons[CommonValues.count].personIdNumber
        carLicenseTLabel.text = User.shared.persons[CommonValues.count].personCarLicense
        adressLabel.text = User.shared.persons[CommonValues.count].adress
    }
    func saveProfileDetailes(){
        User.shared.persons[CommonValues.count].personFirstName = firstNameLabel.text!
        User.shared.persons[CommonValues.count].personLastName = lastNameLabel.text!
        User.shared.persons[CommonValues.count].personAge = Int(ageLabel.text!)!
        User.shared.persons[CommonValues.count].personPhoneNumber = phoneNumberLabel.text!
        User.shared.persons[CommonValues.count].personEmailAdress = emailAdressLabel.text!
        User.shared.persons[CommonValues.count].personCountry = countryLabel.text!
        User.shared.persons[CommonValues.count].personCity = cityLabel.text!
        User.shared.persons[CommonValues.count].personZipCode = Double(zipCodeLabel.text!)!
        User.shared.persons[CommonValues.count].personIdNumber = idNumberLabel.text!
        User.shared.persons[CommonValues.count].personCarLicense = carLicenseTLabel.text!
        User.shared.persons[CommonValues.count].adress = adressLabel.text!
    }
    
    
}
