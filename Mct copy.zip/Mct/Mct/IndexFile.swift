//
//  IndexFile.swift
//  Mct
//
//  Created by maher deeb on 12/10/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import Foundation

struct CommonValues {
    static var count : Int = 0
}
